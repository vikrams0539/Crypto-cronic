<?php include("assets/header.php"); ?>
</head>
<body>
    <main>
        <header class="top_header">
            <div class="topHeader_img_wrapper">
                <div class="menu_section">     
                    <?php include("assets/top-bar.php");  ?>
                </div>
            </div>
        </header>
        <?php include("assets/strategies-banner.php");  ?> 
    </main> 
    
    <?php include("assets/footer.php");  ?>
</body>
</html>