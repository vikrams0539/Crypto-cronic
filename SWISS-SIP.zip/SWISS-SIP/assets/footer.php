<div class="contact_wrap">
    <div class="contact_info row">
        <div class="col-4">
            <div class="contact_info_text">
                <h4>ADDRESS</h4>
                <p>2/3 48 West George Street Glasgow G2 1BP</p>
            </div>
        </div>
        <div class="col-4">
            <div class="contact_info_text">
                <h4>Contacts</h4>
                <p>pn no: xxxxxxxxxxxx</p>
                <p>email:xxxx@spi.com</p>
            </div>
        </div>
        <div class="col-4">
            <div class="contact_info_text">
                <h4>What we do</h4>
                <p>xxxxxxx</p>
            </div>
        </div>
    </div>
    <div class="footer_btn">
        <div class="comm_btn">
            <a  href="<?=$root?>about-us.php" target="_self" class="d-flex">about us</a>
        </div>
    </div>
</div>


<script src="https://kit.fontawesome.com/3fd486c100.js" crossorigin="anonymous"></script>
<script src="js/script.js"></script>
