<section class='w-100'>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="partnersList">
                    <ul class='partners'>
                        <!-- financial-institutions.php, mining-companies.php, metal-purifiers.php, commodity-firms.php  -->
                        <li><a  data-id="id_1" href="<?=$root?>">Financial Institutions</a></li>
                        <li><a data-id="id_2" href="<?=$root?>">Mining Companies</a></li>
                        <li><a data-id="id_3" href="<?=$root?>">Metal Purifiers</a></li>
                        <li><a data-id="id_4" href="<?=$root?>">Commodity Firms</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>