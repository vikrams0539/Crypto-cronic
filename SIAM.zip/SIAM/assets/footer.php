<footer>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-7 col-xl-7 col-xxl-7">
                <div class="footerPolicy">
                    <p>&copy; Swiss International Asset Management SA All rights reserved</p>
                </div>
            </div>
            <!-- <div class="col-xs-12 col-sm-12 col-md-12 col-lg-5 col-xl-5 col-xxl-5">
                <div class="footerPolicy text-end">
                    <p><a href='' >Privacy Policy</a> / <a href='<?=$root?>' >Terms of use</a></p>
                </div>
            </div> -->
        </div>
    </div>
</footer>
<script src="https://kit.fontawesome.com/3fd486c100.js" crossorigin="anonymous"></script>
<script src="<?=$root?>js/app.js" type="text/javascript"></script>
