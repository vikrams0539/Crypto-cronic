<section class="whereItGrown">
    <img src="<?= $website_domain?>images/where-it-grown.jpg" alt="where it’s grown" class='img-fluid'>
    <div class="contextText">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="textBlock">
                        <h2>where it’s grown</h2>
                        <p>Our Galega & Cobrancosa quality olives benefit from the sunshine of the Ribatejo region in Portugal. We produce a very sweet olive oil with a maximum acidity of 0.3.</p>
                        <p><strong>Produced in Ribatejo, Portugal</strong></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>