<footer class="footer comm-tb-p pb-0">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="textBlock">
                    <p>copyright 2022 @Mí Oliv’eira</p>
                </div>
            </div>
        </div>
    </div>
</footer>