<section class="AboutUs comm-tb-p">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="textBlock">
                    <h2>About us</h2>
                    <p>In 1955, Mr. Oliveira decided to start his own olive oil production in the Ribatejo region of Portugal.</p> 
                    <p>A rigorous method ensures a pure product in high demand.</p> 
                    <p> Today, the third generation continues this family tradition.</p> 
                    <p> We take special care of our olive trees and do not use pesticides to treat them.</p> 
                    <p> Thanks to the know-how accumulated over generations, our trees are in perfect health.</p> 
                    <p> We select only the best olives.</p> 
                    <p> The time between harvesting and juice extraction is a maximum of 24 hours. Do </p>
                </div>
            </div>
        </div>
    </div>
</section>